/***************************************************************************
** This file may be distributed under the terms of the Q Public License
** as defined by Trolltech AS of Norway and appearing in the file
** LICENSE.QPL included in the packaging of this file.
**
** This file may be distributed and/or modified under the terms of the
** GNU General Public License version 2 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.
*/
#include "swallow.h"
#include <qlineedit.h>
#include <qlayout.h>
#include <qlabel.h>
#include <qtextstream.h>
#include <qpushbutton.h>

#include <qtxembed.h>

Embedder::Embedder(QWidget *parent, const char *name, WFlags f)
    : QWidget(parent, name, f)
{
    QVBoxLayout *layout = new QVBoxLayout(this);

    QHBoxLayout *hbox = new QHBoxLayout(layout);

    input = new QLineEdit(this);
    hbox->addWidget(input);

    QPushButton *embedButton = new QPushButton("&Embed", this);
    hbox->addWidget(embedButton);

    container = new QtXEmbedContainer(this);
    layout->addWidget(container);

    QHBoxLayout *hbox2 = new QHBoxLayout(layout);

    QPushButton *button = new QPushButton("&Discard", this);
    hbox2->addWidget(button);
    QPushButton *quitButton = new QPushButton("&Quit", this);
    hbox2->addWidget(quitButton);

    display = new QLabel(this);
    display->setText("Ready.");
    layout->addWidget(display);

    connect(embedButton, SIGNAL(clicked()), SLOT(swallow()));
    connect(quitButton, SIGNAL(clicked()), SLOT(close()));
    connect(button, SIGNAL(clicked()), SLOT(reject()));
    connect(container, SIGNAL(clientIsEmbedded()), SLOT(showClientEmbedded()));
    connect(container, SIGNAL(clientClosed()), SLOT(showClientClosed()));
    connect(container, SIGNAL(error(int)), SLOT(showClientError(int)));
}

void Embedder::swallow()
{
    QString id = input->text();
    if (id.left(2) != "0x") {
	container->embed(input->text().toInt(), false);
    } else {
	bool ok;
	int intid = id.mid(2).toInt(&ok, 16);

	qDebug("embedding %i", intid);

	container->embed(intid, false);
    }
}

void Embedder::reject()
{
    container->discardClient();
    display->setText("Ready.");
}

void Embedder::showClientEmbedded()
{
    display->setText("Client is embedded.");
}

void Embedder::showClientClosed()
{
    display->setText("Client closed.");
}

void Embedder::showClientError(int err)
{
    switch (err) {
	case QtXEmbedContainer::Unknown:
	    display->setText("Unknown error.");
	    break;
	case QtXEmbedContainer::InvalidWindowID:
	    display->setText("Invalid window ID.");
	    break;
    }
}
