/***************************************************************************
** This file may be distributed under the terms of the Q Public License
** as defined by Trolltech AS of Norway and appearing in the file
** LICENSE.QPL included in the packaging of this file.
**
** This file may be distributed and/or modified under the terms of the
** GNU General Public License version 2 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.
*/
#ifndef SWALLOW_H
#define SWALLOW_H
#include <qwidget.h>

class QtXEmbedContainer;
class QLineEdit;
class QLabel;

class Embedder : public QWidget
{
    Q_OBJECT
public:
    Embedder(QWidget *parent = 0, const char *name = 0, WFlags f = 0);

private slots:
    void swallow();
    void reject();
    void showClientEmbedded();
    void showClientClosed();
    void showClientError(int err);

private:
    QtXEmbedContainer *container;
    QLineEdit *input;
    QLabel *display;
};


#endif
