/***************************************************************************
** This file may be distributed under the terms of the Q Public License
** as defined by Trolltech AS of Norway and appearing in the file
** LICENSE.QPL included in the packaging of this file.
**
** This file may be distributed and/or modified under the terms of the
** GNU General Public License version 2 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.
*/
#ifndef DEMOWIDGET_H
#define DEMOWIDGET_H
#include <qmap.h>
#include <qlayout.h>
#include <qstring.h>

#include <qtxembed.h>

class DemoWidget : public QtXEmbedClient
{
    Q_OBJECT

public:
    DemoWidget(const QString &argv0, int indent = 0, QWidget *parent = 0, const char *name = 0);

private slots:
    void addSibling();
    void addChild();
    void shutDown();

private:
    QString arg0;
    int ind;
    QMap<QObject *, QtXEmbedContainer *> containers;
    QVBoxLayout *vlayout;
};

#endif
