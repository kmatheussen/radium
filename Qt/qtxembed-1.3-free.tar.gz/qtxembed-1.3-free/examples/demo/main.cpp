/***************************************************************************
** This file may be distributed under the terms of the Q Public License
** as defined by Trolltech AS of Norway and appearing in the file
** LICENSE.QPL included in the packaging of this file.
**
** This file may be distributed and/or modified under the terms of the
** GNU General Public License version 2 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.
*/
#include <qapplication.h>
#include "demowidget.h"

#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

#include <qvaluelist.h>

QValueList<int> children;

void sighandler(int)
{
    QValueList<int>::Iterator it = children.begin();
    while (it != children.end()) {
	kill(*it, SIGINT);
	++it;
    }

    exit(0);
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_handler = sighandler;

    sigaction(SIGINT, &action, 0);
    sigaction(SIGTERM, &action, 0);

    if (argc > 1) {
	Window id;
	if (argv[1][0] == '0') sscanf(argv[1], "0x%x", (unsigned int *)&id);
	else sscanf(argv[1], "%li", &id);

	DemoWidget demo(argv[0], argc > 2 ? atoi(argv[2]) : 0);

	app.setMainWidget(&demo);

	demo.embedInto(id);
	demo.show();
	return app.exec();
    } else {
	DemoWidget demo(argv[0]);

	app.setMainWidget(&demo);

	demo.show();
	return app.exec();
    }
}
