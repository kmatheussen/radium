/***************************************************************************
** This file may be distributed under the terms of the Q Public License
** as defined by Trolltech AS of Norway and appearing in the file
** LICENSE.QPL included in the packaging of this file.
**
** This file may be distributed and/or modified under the terms of the
** GNU General Public License version 2 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.
*/
#include <qgroupbox.h>
#include <qlayout.h>
#include <qpushbutton.h>
#include <qvaluelist.h>
#include <qhbox.h>

#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

#include "demowidget.h"

extern QValueList<int> children;

DemoWidget::DemoWidget(const QString &argv0, int indent,
		       QWidget *parent, const char *name)
    : QtXEmbedClient(parent, name), arg0(argv0)
{
    ind = indent;
    vlayout = new QVBoxLayout(this);

    addSibling();
}

void DemoWidget::addSibling()
{
    QGroupBox *box = new QGroupBox("Level " + QString::number(ind), this);
    box->setInsideMargin(8);
    box->setColumnLayout(2, Horizontal);

    vlayout->addWidget(box);

    QHBox *hbox = new QHBox(box);
    QPushButton *button = new QPushButton("New Sibling", hbox, "Add Sibling Button in DemoWidget");
    QPushButton *childbutton = new QPushButton("New Child", hbox, "Add Child Button in DemoWidget");

    QPushButton *closebutton = new QPushButton("Close", box, "CloseButton in DemoWidget");

    QtXEmbedContainer *embed = new QtXEmbedContainer(box);
    connect(embed, SIGNAL(clientClosed()), SLOT(close()));
    containers[childbutton] = embed;

    connect(button, SIGNAL(clicked()), SLOT(addSibling()));
    connect(childbutton, SIGNAL(clicked()), SLOT(addChild()));
    connect(closebutton, SIGNAL(clicked()), SLOT(shutDown()));

    box->show();
}

void DemoWidget::addChild()
{
    QtXEmbedContainer *embed = containers[(QObject *)sender()];
    int childspid = fork();
    if (childspid == 0) {
	execl(arg0.latin1(), arg0.latin1(), QString::number(embed->winId()).latin1(),
	      QString::number(ind + 1).latin1(), NULL);
	exit(1);
    }

    ::children.push_back(childspid);

    QPushButton *b = (QPushButton *)sender();
    b->setEnabled(false);
}

void DemoWidget::shutDown()
{
    QValueList<int>::Iterator it = ::children.begin();
    while (it != ::children.end()) {
	kill(*it, SIGINT);
	++it;
    }

    ::children.clear();

    close();
}
