//
//  iOSTests.h
//  iOSTests
//
//  Created by Olivier Guillerminet on 02/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface iOSTests : SenTestCase

@end
