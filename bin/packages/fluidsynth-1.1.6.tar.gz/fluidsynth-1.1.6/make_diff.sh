diff -ru src_org src|grep -v ^Binary\ files|grep -v ^Only\ in >fluid_const_sample_patch.diff

diff -ru include_org include|grep -v ^Binary\ files|grep -v ^Only\ in >>fluid_const_sample_patch.diff

