#define HAVE_STRING_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STDIO_H 1
#define HAVE_MATH_H 1
#define HAVE_STDARG_H 1

#if defined(__POWERPC__)
#define WORDS_BIGENDIAN 1
#endif

#define STDIN_FILENO 0
#define STDOUT_FILENO 1
