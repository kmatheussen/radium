//#include "faust/gui/FUI.h"
#include "faust/misc.h"
#include "faust/gui/APIUI.h"
#include "faust/dsp/dsp.h"
#include "faust/audio/coreaudio-ios-dsp.h"

<<includeIntrinsic>>

<<includeclass>>
	
#include "faust/dsp/poly-dsp.h"
#include "faust/dsp/dsp-combiner.h"
