# The Faust Project

The Faust Project has started in 2002. It is actively developed by the [Grame Research Lab](https://www.grame.fr/recherche).

Many persons are contributing to the Faust project, by providing code for the 
compiler, architecture files, libraries, examples, documentation, scripts, bug 
reports, ideas, etc. We would like in particular to thank:

<ul>
Fons&nbsp;Adriaensen, Karim&nbsp;Barkati,
Jérôme&nbsp;Barthélemy, Tim&nbsp;Blechmann, 
Tiziano&nbsp;Bole, Alain&nbsp;Bonardi, 
Thomas&nbsp;Charbonnel, Raffaele&nbsp;Ciavarella, 
Julien&nbsp;Colafrancesco, Damien&nbsp;Cramet, 
Sarah&nbsp;Denoux, Étienne&nbsp;Gaudrin, 
Olivier&nbsp;Guillerminet, Pierre&nbsp;Guillot, 
Albert&nbsp;Gräf, Pierre&nbsp;Jouvelot, 
Stefan&nbsp;Kersten, Victor&nbsp;Lazzarini, 
Matthieu&nbsp;Leberre, Mathieu&nbsp;Leroi, 
Fernando&nbsp;Lopez-Lezcano, Kjetil&nbsp;Matheussen, 
Hermann&nbsp;Meyer, Rémy&nbsp;Muller, 
Raphael&nbsp;Panis, Eliott&nbsp;Paris, 
Reza&nbsp;Payami, Laurent&nbsp;Pottier, 
Sampo&nbsp;Savolainen, Nicolas&nbsp;Scaringella, 
Anne&nbsp;Sedes, Priyanka&nbsp;Shekar, 
Stephen&nbsp;Sinclair, Travis&nbsp;Skare, 
Julius&nbsp;Smith, Mike&nbsp;Solomon, 
Michael&nbsp;Wilson, Bart Brouns, Dirk Roosenburg,
Riccardo Russo.
</ul>

as well as our colleagues at [GRAME](http://grame.fr):

- Dominique Fober
- Christophe Lebreton
- Stéphane Letz
- Romain Michon
- Yann Orlarey 

We would like also to thank for their financial support:

- the [French Ministry of Culture](http://www.culture.gouv.fr/),
- the [Auvergne-Rhône-Alpes Region](https://www.auvergnerhonealpes.fr/),
- the [City of Lyon](https://www.lyon.fr/),
- the [French National Research Agency (ANR)](http://www.agence-nationale-recherche.fr/).
