# Description

Modeled after T. Rossing and R. Perrin, Vibrations of Bells, Applied Acoustics 2, 1987.

Model height is 301 mm.

To turn `carillonBell.obj` into a Faust physical model (`carillonBellModel.lib`), just run `./build`.
