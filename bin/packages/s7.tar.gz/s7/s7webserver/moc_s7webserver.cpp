/****************************************************************************
** Meta object code from reading C++ file 's7webserver.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "s7webserver.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 's7webserver.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_S7WebServer[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      22,   13,   12,   12, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_S7WebServer[] = {
    "S7WebServer\0\0req,resp\0"
    "handleRequest(QHttpRequest*,QHttpResponse*)\0"
};

void S7WebServer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        S7WebServer *_t = static_cast<S7WebServer *>(_o);
        switch (_id) {
        case 0: _t->handleRequest((*reinterpret_cast< QHttpRequest*(*)>(_a[1])),(*reinterpret_cast< QHttpResponse*(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData S7WebServer::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject S7WebServer::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_S7WebServer,
      qt_meta_data_S7WebServer, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &S7WebServer::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *S7WebServer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *S7WebServer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_S7WebServer))
        return static_cast<void*>(const_cast< S7WebServer*>(this));
    return QObject::qt_metacast(_clname);
}

int S7WebServer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_S7WebServerResponder[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      22,   21,   21,   21, 0x05,

 // slots: signature, parameters, type, tag, flags
      34,   29,   21,   21, 0x08,
      57,   21,   21,   21, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_S7WebServerResponder[] = {
    "S7WebServerResponder\0\0done()\0data\0"
    "accumulate(QByteArray)\0reply()\0"
};

void S7WebServerResponder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        S7WebServerResponder *_t = static_cast<S7WebServerResponder *>(_o);
        switch (_id) {
        case 0: _t->done(); break;
        case 1: _t->accumulate((*reinterpret_cast< const QByteArray(*)>(_a[1]))); break;
        case 2: _t->reply(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData S7WebServerResponder::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject S7WebServerResponder::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_S7WebServerResponder,
      qt_meta_data_S7WebServerResponder, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &S7WebServerResponder::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *S7WebServerResponder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *S7WebServerResponder::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_S7WebServerResponder))
        return static_cast<void*>(const_cast< S7WebServerResponder*>(this));
    return QObject::qt_metacast(_clname);
}

int S7WebServerResponder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void S7WebServerResponder::done()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
