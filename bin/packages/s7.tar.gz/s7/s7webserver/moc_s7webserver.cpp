/****************************************************************************
** Meta object code from reading C++ file 's7webserver.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "s7webserver.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 's7webserver.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_S7WebServer_t {
    QByteArrayData data[7];
    char stringdata0[65];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_S7WebServer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_S7WebServer_t qt_meta_stringdata_S7WebServer = {
    {
QT_MOC_LITERAL(0, 0, 11), // "S7WebServer"
QT_MOC_LITERAL(1, 12, 13), // "handleRequest"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 13), // "QHttpRequest*"
QT_MOC_LITERAL(4, 41, 3), // "req"
QT_MOC_LITERAL(5, 45, 14), // "QHttpResponse*"
QT_MOC_LITERAL(6, 60, 4) // "resp"

    },
    "S7WebServer\0handleRequest\0\0QHttpRequest*\0"
    "req\0QHttpResponse*\0resp"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_S7WebServer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   19,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5,    4,    6,

       0        // eod
};

void S7WebServer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        S7WebServer *_t = static_cast<S7WebServer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->handleRequest((*reinterpret_cast< QHttpRequest*(*)>(_a[1])),(*reinterpret_cast< QHttpResponse*(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObject S7WebServer::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_S7WebServer.data,
      qt_meta_data_S7WebServer,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *S7WebServer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *S7WebServer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_S7WebServer.stringdata0))
        return static_cast<void*>(const_cast< S7WebServer*>(this));
    return QObject::qt_metacast(_clname);
}

int S7WebServer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_S7WebServerResponder_t {
    QByteArrayData data[6];
    char stringdata0[49];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_S7WebServerResponder_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_S7WebServerResponder_t qt_meta_stringdata_S7WebServerResponder = {
    {
QT_MOC_LITERAL(0, 0, 20), // "S7WebServerResponder"
QT_MOC_LITERAL(1, 21, 4), // "done"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 10), // "accumulate"
QT_MOC_LITERAL(4, 38, 4), // "data"
QT_MOC_LITERAL(5, 43, 5) // "reply"

    },
    "S7WebServerResponder\0done\0\0accumulate\0"
    "data\0reply"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_S7WebServerResponder[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   29,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    1,   30,    2, 0x08 /* Private */,
       5,    0,   33,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QByteArray,    4,
    QMetaType::Void,

       0        // eod
};

void S7WebServerResponder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        S7WebServerResponder *_t = static_cast<S7WebServerResponder *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->done(); break;
        case 1: _t->accumulate((*reinterpret_cast< const QByteArray(*)>(_a[1]))); break;
        case 2: _t->reply(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (S7WebServerResponder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&S7WebServerResponder::done)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject S7WebServerResponder::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_S7WebServerResponder.data,
      qt_meta_data_S7WebServerResponder,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *S7WebServerResponder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *S7WebServerResponder::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_S7WebServerResponder.stringdata0))
        return static_cast<void*>(const_cast< S7WebServerResponder*>(this));
    return QObject::qt_metacast(_clname);
}

int S7WebServerResponder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void S7WebServerResponder::done()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
