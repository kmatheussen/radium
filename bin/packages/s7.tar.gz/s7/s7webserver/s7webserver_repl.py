#! /usr/bin/env python

# Written by Kjetil Matheussen: k.s.matheussen@notam02.no


import sys
import urllib2
import readline

prompt = "s7> "
url = "http://localhost:5080"
    
if len(sys.argv)>1:
    if (sys.argv[1].startswith("-")):
        print "Usage: s7repl <prompt> <url>"
        print "       Default value for <prompt> is \"s7> \""
        print "       Default value for <url> is http://localhost:5080"
        sys.exit(0)
    prompt = sys.argv[1]
    
if len(sys.argv)>2:
    url = sys.argv[2]


headers = {"Content-type": "text/plain", "Accept": "text/plain"}

    
def post(data):
    request = urllib2.Request(url, data, headers)
    response = urllib2.urlopen(request)

    all_data = ""
    
    data = response.read(1)
    while data:
        all_data = all_data + data
        sys.stdout.write( '%s' % data )
        sys.stdout.flush()
        data = response.read(1)
    response.close()
    print

    return all_data

line = raw_input(prompt)
while True:
    try:
        result = post(line)
        if result==" ":
            line = raw_input("")
        else:
            line = raw_input(prompt)
    except EOFError:
        break

