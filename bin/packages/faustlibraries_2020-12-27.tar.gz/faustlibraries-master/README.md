# Faust Libraries

This repository contains the source code and the documentation of the DSP libraries of the [Faust Programming Language](https://faust.grame.fr). 

Here is the [online documentation](https://faustlibraries.grame.fr) of the Faust libraries (which also serves as a proper README for this repository).
