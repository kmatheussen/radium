# Description

Modeled after D. Bartocha and . Baron, Influence of Tin Bronze Melting and Pouring Parameters on Its Properties and Bell' Tone, Archives of Foundry Engineering, 2016.

Model height is 1 meter.

To turn `germanBell.obj` into a Faust physical model (`germanBellModel.lib`), just run `./build`.
