#!/usr/bin/env python

# Qt tutorial 3.

import sys
import qt


a = qt.QApplication(sys.argv)

box = qt.QVBox()
box.resize(200, 120)

quit = qt.QPushButton("Quit", box)
quit.setFont(qt.QFont("Times", 18, qt.QFont.Bold))

qt.QObject.connect(quit, qt.SIGNAL("clicked()"), a, qt.SLOT("quit()"))

a.setMainWidget(box)
box.show()
sys.exit(a.exec_loop())
