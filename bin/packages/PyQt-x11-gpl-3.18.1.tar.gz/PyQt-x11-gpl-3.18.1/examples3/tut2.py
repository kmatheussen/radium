#!/usr/bin/env python

# Qt tutorial 2.

import sys
import qt


a = qt.QApplication(sys.argv)

quit = qt.QPushButton("Quit", None)
quit.resize(75, 30)
quit.setFont(qt.QFont("Times", 18, qt.QFont.Bold))

qt.QObject.connect(quit, qt.SIGNAL("clicked()"), a, qt.SLOT("quit()"))

a.setMainWidget(quit)
quit.show()
sys.exit(a.exec_loop())
