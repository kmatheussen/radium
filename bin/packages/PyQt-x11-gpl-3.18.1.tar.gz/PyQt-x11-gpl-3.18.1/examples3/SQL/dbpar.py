# sql examples default database parameter

# you can create a local_dbpar.py module with definitons
# of your own parameters to overrule these defaults

#DB_DRIVER = "QPSQL7"
DB_DRIVER = "QMYSQL3"
# list of servers
DB_HOSTNAMES = ["localhost"]
# list of databases
DB_DATABASES = ["testdb"]
# database user id
DB_USERNAME = ""
# database password
DB_PASSWORD = ""

# remove this in your local_dbpar.py
try:
    from local_dbpar import *
except:
    pass

