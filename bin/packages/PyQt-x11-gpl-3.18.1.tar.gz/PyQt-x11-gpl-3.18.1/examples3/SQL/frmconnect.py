# Form implementation generated from reading ui file 'frmconnect.ui'
#
# Created: Sam Jul 6 12:47:10 2002
#      by: The PyQt User Interface Compiler (pyuic)
#
# WARNING! All changes made in this file will be lost!


from qt import *


class frmConnect(QDialog):
    def __init__(self,parent = None,name = None,modal = 0,fl = 0):
        QDialog.__init__(self,parent,name,modal,fl)

        if name == None:
            self.setName("frmConnect")

        self.resize(415,154)
        self.setCaption(self.trUtf8("Connecting"))
        self.setSizeGripEnabled(1)

        frmConnectLayout = QGridLayout(self,1,1,11,6,"frmConnectLayout")

        Layout7 = QVBoxLayout(None,0,6,"Layout7")

        self.buttonOK = QPushButton(self,"buttonOK")
        self.buttonOK.setText(self.trUtf8("&OK"))
        self.buttonOK.setAutoDefault(1)
        self.buttonOK.setDefault(1)
        QToolTip.add(self.buttonOK,self.trUtf8("Connect to Database"))
        Layout7.addWidget(self.buttonOK)

        self.buttonCancel = QPushButton(self,"buttonCancel")
        self.buttonCancel.setText(self.trUtf8("&Cancel"))
        QToolTip.add(self.buttonCancel,self.trUtf8("Cancel Connecting"))
        Layout7.addWidget(self.buttonCancel)

        self.buttonHelp = QPushButton(self,"buttonHelp")
        self.buttonHelp.setText(self.trUtf8("&Help"))
        QToolTip.add(self.buttonHelp,self.trUtf8("About Connecting"))
        Layout7.addWidget(self.buttonHelp)
        spacer = QSpacerItem(0,0,QSizePolicy.Minimum,QSizePolicy.Expanding)
        Layout7.addItem(spacer)

        frmConnectLayout.addLayout(Layout7,0,1)

        self.grpConnection = QGroupBox(self,"grpConnection")
        self.grpConnection.setTitle(self.trUtf8(""))
        self.grpConnection.setColumnLayout(0,Qt.Vertical)
        self.grpConnection.layout().setSpacing(6)
        self.grpConnection.layout().setMargin(11)
        grpConnectionLayout = QGridLayout(self.grpConnection.layout())
        grpConnectionLayout.setAlignment(Qt.AlignTop)

        self.txtName = QLineEdit(self.grpConnection,"txtName")
        self.txtName.setMaxLength(16)
        QToolTip.add(self.txtName,self.trUtf8("Database User ID"))

        grpConnectionLayout.addWidget(self.txtName,0,1)

        self.lblDatabase = QLabel(self.grpConnection,"lblDatabase")
        self.lblDatabase.setText(self.trUtf8("&Database"))

        grpConnectionLayout.addWidget(self.lblDatabase,3,0)

        self.lblServer = QLabel(self.grpConnection,"lblServer")
        self.lblServer.setText(self.trUtf8("&Server"))

        grpConnectionLayout.addWidget(self.lblServer,2,0)

        self.lblName = QLabel(self.grpConnection,"lblName")
        self.lblName.setText(self.trUtf8("&Name"))

        grpConnectionLayout.addWidget(self.lblName,0,0)

        self.cmbDatabase = QComboBox(0,self.grpConnection,"cmbDatabase")
        self.cmbDatabase.setEditable(1)
        self.cmbDatabase.setAutoCompletion(1)
        self.cmbDatabase.setDuplicatesEnabled(0)
        QToolTip.add(self.cmbDatabase,self.trUtf8("Database Name"))

        grpConnectionLayout.addWidget(self.cmbDatabase,3,1)

        self.txtPasswd = QLineEdit(self.grpConnection,"txtPasswd")
        self.txtPasswd.setMaxLength(16)
        self.txtPasswd.setEchoMode(QLineEdit.Password)
        QToolTip.add(self.txtPasswd,self.trUtf8("Database User Password"))

        grpConnectionLayout.addWidget(self.txtPasswd,1,1)

        self.lblPasswd = QLabel(self.grpConnection,"lblPasswd")
        self.lblPasswd.setText(self.trUtf8("&Password"))

        grpConnectionLayout.addWidget(self.lblPasswd,1,0)

        self.cmbServer = QComboBox(0,self.grpConnection,"cmbServer")
        self.cmbServer.setEditable(1)
        self.cmbServer.setAutoCompletion(1)
        self.cmbServer.setDuplicatesEnabled(0)
        QToolTip.add(self.cmbServer,self.trUtf8("Database Server Address"))

        grpConnectionLayout.addWidget(self.cmbServer,2,1)

        frmConnectLayout.addWidget(self.grpConnection,0,0)

        self.connect(self.buttonOK,SIGNAL("clicked()"),self,SLOT("accept()"))
        self.connect(self.buttonCancel,SIGNAL("clicked()"),self,SLOT("reject()"))

        self.setTabOrder(self.txtName,self.txtPasswd)
        self.setTabOrder(self.txtPasswd,self.cmbServer)
        self.setTabOrder(self.cmbServer,self.cmbDatabase)
        self.setTabOrder(self.cmbDatabase,self.buttonOK)
        self.setTabOrder(self.buttonOK,self.buttonCancel)
        self.setTabOrder(self.buttonCancel,self.buttonHelp)

        self.lblDatabase.setBuddy(self.cmbDatabase)
        self.lblServer.setBuddy(self.cmbServer)
        self.lblName.setBuddy(self.txtName)
        self.lblPasswd.setBuddy(self.txtPasswd)
