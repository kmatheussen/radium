#!/usr/bin/env python

import sys
from qt import *

from form1 import Form1
from dbconnect import createConnection

class mainWindow(Form1):
    def __init__(self,parent = None,name = None,fl = 0):
        Form1.__init__(self,parent,name,fl)

if __name__ == "__main__":
    a = QApplication(sys.argv)
    if createConnection():
        QObject.connect(a,SIGNAL("lastWindowClosed()"),a,SLOT("quit()"))
        w = mainWindow()
        a.setMainWidget(w)
        w.show()
        a.exec_loop()

