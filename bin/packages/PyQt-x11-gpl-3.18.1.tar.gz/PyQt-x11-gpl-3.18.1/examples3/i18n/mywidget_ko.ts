<!DOCTYPE TS><TS>
<context encoding="UTF-8">
    <name>MyWidget</name>
    <message encoding="UTF-8">
        <source>&amp;File</source>
        <translation type="unfinished">파일&amp;F</translation>
    </message>
    <message encoding="UTF-8">
        <source>Ctrl+Q</source>
        <translation type="unfinished">Ctrl+E</translation>
    </message>
    <message encoding="UTF-8">
        <source>E&amp;xit</source>
        <translation type="unfinished">종료&amp;X</translation>
    </message>
    <message encoding="UTF-8">
        <source>First</source>
        <translation type="unfinished">첫번째</translation>
    </message>
    <message encoding="UTF-8">
        <source>Internationalization Example</source>
        <translation type="unfinished">국제화 예제</translation>
    </message>
    <message encoding="UTF-8">
        <source>Isometric</source>
        <translation type="unfinished">Isometric</translation>
    </message>
    <message encoding="UTF-8">
        <source>Language: English</source>
        <translation type="unfinished">언어 : 한국어</translation>
    </message>
    <message encoding="UTF-8">
        <source>Oblique</source>
        <translation type="unfinished">Oblique</translation>
    </message>
    <message encoding="UTF-8">
        <source>Perspective</source>
        <translation type="unfinished">Perspective</translation>
    </message>
    <message encoding="UTF-8">
        <source>Second</source>
        <translation type="unfinished">두번째</translation>
    </message>
    <message encoding="UTF-8">
        <source>The Main Window</source>
        <translation type="unfinished">메인 윈도우</translation>
    </message>
    <message encoding="UTF-8">
        <source>Third</source>
        <translation type="unfinished">세번째</translation>
    </message>
    <message encoding="UTF-8">
        <source>View</source>
        <translation type="unfinished">보기</translation>
    </message>
</context>
<context>
    <name>QVDialog</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
