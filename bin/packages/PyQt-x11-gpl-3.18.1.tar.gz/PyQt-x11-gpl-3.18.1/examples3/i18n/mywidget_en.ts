<!DOCTYPE TS><TS>
<context>
    <name>MyWidget</name>
    <message>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Third</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language: English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Main Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <comment>File|Quit</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QVDialog</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
