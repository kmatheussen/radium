<!DOCTYPE TS><TS>
<context encoding="UTF-8">
    <name>MyWidget</name>
    <message encoding="UTF-8">
        <source>&amp;File</source>
        <translation type="unfinished">ファイル(&amp;F)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Ctrl+Q</source>
        <translation type="unfinished">Ctrl+Q</translation>
    </message>
    <message encoding="UTF-8">
        <source>E&amp;xit</source>
        <translation type="unfinished">終了(&amp;X)</translation>
    </message>
    <message encoding="UTF-8">
        <source>First</source>
        <translation type="unfinished">第一行</translation>
    </message>
    <message encoding="UTF-8">
        <source>Internationalization Example</source>
        <translation type="unfinished">国際化(i18n)の例</translation>
    </message>
    <message encoding="UTF-8">
        <source>Isometric</source>
        <translation type="unfinished">等角投影法</translation>
    </message>
    <message encoding="UTF-8">
        <source>Language: English</source>
        <translation type="unfinished">言語: 日本語</translation>
    </message>
    <message encoding="UTF-8">
        <source>Oblique</source>
        <translation type="unfinished">斜め投影法</translation>
    </message>
    <message encoding="UTF-8">
        <source>Perspective</source>
        <translation type="unfinished">遠近法</translation>
    </message>
    <message encoding="UTF-8">
        <source>Second</source>
        <translation type="unfinished">第二行</translation>
    </message>
    <message encoding="UTF-8">
        <source>The Main Window</source>
        <translation type="unfinished">メインウィンドウ</translation>
    </message>
    <message encoding="UTF-8">
        <source>Third</source>
        <translation type="unfinished">第三行</translation>
    </message>
    <message encoding="UTF-8">
        <source>View</source>
        <translation type="unfinished">表示方式</translation>
    </message>
</context>
<context>
    <name>QVDialog</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
