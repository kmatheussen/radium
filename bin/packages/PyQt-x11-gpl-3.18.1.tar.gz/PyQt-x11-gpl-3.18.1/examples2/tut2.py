#!/usr/bin/env python

# Qt tutorial 2.

import sys
from qt import *


a = QApplication(sys.argv)

quit = QPushButton("Quit",None)
quit.resize(75,30)
quit.setFont(QFont("Times",18,QFont.Bold))

QObject.connect(quit,SIGNAL("clicked()"),a,SLOT("quit()"))

a.setMainWidget(quit)
quit.show()
a.exec_loop()
