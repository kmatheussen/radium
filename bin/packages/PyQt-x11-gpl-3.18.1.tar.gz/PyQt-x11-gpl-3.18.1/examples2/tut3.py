#!/usr/bin/env python

# Qt tutorial 3.

import sys
from qt import *

a = QApplication(sys.argv)

box = QVBox()
box.resize(200,120)

quit = QPushButton("Quit",box)
quit.setFont(QFont("Times",18,QFont.Bold))

QObject.connect(quit,SIGNAL("clicked()"),a,SLOT("quit()"))

a.setMainWidget(box)
box.show()
a.exec_loop()
