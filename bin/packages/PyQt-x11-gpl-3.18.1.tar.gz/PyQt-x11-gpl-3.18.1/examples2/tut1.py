#!/usr/bin/env python

# Qt tutorial 1.

import sys
from qt import *


a = QApplication(sys.argv)

hello = QPushButton("Hello world!",None)
hello.resize(100,30)

a.setMainWidget(hello)
hello.show()
a.exec_loop()
