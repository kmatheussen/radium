#include "gfsmConfigAuto.h"
