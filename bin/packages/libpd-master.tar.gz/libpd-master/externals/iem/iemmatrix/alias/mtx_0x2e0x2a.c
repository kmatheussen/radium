// alias for [mtx_.*]
#include "../src/mtx_mul.c"
void mtx_0x2e0x2a_setup()
{
  mtx_mul_setup();
}
