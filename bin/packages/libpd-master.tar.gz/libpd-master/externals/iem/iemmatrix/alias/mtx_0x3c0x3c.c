// alias for [mtx_<<]
#include "../src/mtx_bitleft.c"
void mtx_0x3c0x3c_setup()
{
  mtx_bitleft_setup();
}
