// alias for [mtx_==]
#include "../src/mtx_eq.c"
void mtx_0x3d0x3d_setup()
{
  mtx_eq_setup();
}
