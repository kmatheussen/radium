// alias for [mtx_+]
#include "../src/mtx_add.c"
void mtx_0x2b_setup()
{
  mtx_add_setup();
}
