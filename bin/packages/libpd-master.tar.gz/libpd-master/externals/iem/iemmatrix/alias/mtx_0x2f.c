#include "../src/mtx_mul.c"
void mtx_0x2f_setup()
{
  mtx_div_setup();
}
