// alias for [mtx_||]
#include "../src/mtx_or.c"
void mtx_0x7c0x7c_setup()
{
  mtx_or_setup();
}
