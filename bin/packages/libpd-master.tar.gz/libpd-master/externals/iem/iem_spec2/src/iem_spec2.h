/* For information on usage and redistribution, and for a DISCLAIMER OF ALL
* WARRANTIES, see the file, "LICENSE.txt," in this distribution.

iem_spec2 written by Thomas Musil, Copyright (c) IEM KUG Graz Austria 2000 - 2009 */

#ifndef __IEMSPEC2_H__
#define __IEMSPEC2_H__

#define DELLINE_DEF_VEC_SIZE 64

#endif
