#include "vradio.c"
void vdl_setup(void) 
{
	vradio_setup();
}
