#include "../../pd/src/x_connective.c"
void lib_x_connective_setup(void)
{
    x_connective_setup();
}
