#include "../../pd/src/d_array.c"
void lib_d_array_setup(void)
{
    d_array_setup();
}
