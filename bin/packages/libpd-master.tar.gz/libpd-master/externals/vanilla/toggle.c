#include "tgl.c"
void toggle_setup(void) 
{
	tgl_setup();
}

