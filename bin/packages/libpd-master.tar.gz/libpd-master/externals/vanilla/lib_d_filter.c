#include "../../pd/src/d_filter.c"
void lib_d_filter_setup(void)
{
    d_filter_setup();
}
