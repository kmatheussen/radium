#include "cnv.c"
void my_canvas_setup(void) 
{
	cnv_setup();
}

