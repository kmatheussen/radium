#include "hradio.c"
void radiobutton_setup(void) 
{
	hradio_setup();
}

