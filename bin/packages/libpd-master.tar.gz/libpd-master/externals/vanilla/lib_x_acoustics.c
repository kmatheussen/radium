#include "../../pd/src/x_acoustics.c"
void lib_x_acoustics_setup(void)
{
    x_acoustics_setup();
}
