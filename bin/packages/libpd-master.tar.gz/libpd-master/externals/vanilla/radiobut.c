#include "hradio.c"
void radiobut_setup(void) 
{
	hradio_setup();
}

