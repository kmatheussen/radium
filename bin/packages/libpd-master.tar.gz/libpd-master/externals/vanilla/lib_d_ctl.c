#include "../../pd/src/d_ctl.c"
void lib_d_ctl_setup(void)
{
    d_ctl_setup();
}
