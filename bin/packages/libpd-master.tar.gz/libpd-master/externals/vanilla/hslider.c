#include "hsl.c"
void hslider_setup(void) 
{
	hsl_setup();
}
