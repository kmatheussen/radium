#include "../../pd/src/d_global.c"
void lib_d_global_setup(void)
{
    d_global_setup();
}
