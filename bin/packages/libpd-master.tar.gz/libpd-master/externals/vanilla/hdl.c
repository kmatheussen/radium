#include "hradio.c"
void hdl_setup(void) 
{
	hradio_setup();
}
