#include "../../pd/src/x_midi.c"
void lib_x_midi_setup(void)
{
    x_midi_setup();
}
