#include "nbx.c"
void my_numbox_setup(void) 
{
	nbx_setup();
}

