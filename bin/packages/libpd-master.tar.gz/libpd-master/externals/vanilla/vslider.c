#include "vsl.c"
void vslider_setup(void) 
{
	vsl_setup();
}
