#include "../../pd/src/d_ugen.c"
void lib_d_ugen_setup(void)
{
    d_ugen_setup();
}
