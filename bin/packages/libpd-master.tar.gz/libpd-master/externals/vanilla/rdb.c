#include "hradio.c"
void rdb_setup(void) 
{
	hradio_setup();
}

