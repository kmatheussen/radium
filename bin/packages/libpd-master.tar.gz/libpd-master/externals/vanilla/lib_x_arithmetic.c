#include "../../pd/src/x_arithmetic.c"
void lib_x_arithmetic_setup(void)
{
    x_arithmetic_setup();
}
