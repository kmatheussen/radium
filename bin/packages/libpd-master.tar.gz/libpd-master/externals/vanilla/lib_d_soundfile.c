#include "../../pd/src/d_soundfile.c"
void lib_d_soundfile_setup(void)
{
    d_soundfile_setup();
}
