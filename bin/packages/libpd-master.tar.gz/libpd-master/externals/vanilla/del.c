#include "delay.c"
void del_setup(void) 
{
	delay_setup();
}

