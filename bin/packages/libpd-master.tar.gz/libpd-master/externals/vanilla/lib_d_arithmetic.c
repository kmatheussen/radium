#include "../../pd/src/d_arithmetic.c"
void lib_d_arithmetic_setup(void)
{
    d_arithmetic_setup();
}
