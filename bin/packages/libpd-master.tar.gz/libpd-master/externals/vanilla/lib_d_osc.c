#include "../../pd/src/d_osc.c"
void lib_d_osc_setup(void)
{
    d_osc_setup();
}
