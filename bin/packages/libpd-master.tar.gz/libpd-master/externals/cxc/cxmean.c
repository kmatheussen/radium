#include "mean~.c"
