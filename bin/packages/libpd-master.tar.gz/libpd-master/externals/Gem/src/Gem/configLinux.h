/* configLinux.h : dummy file to be included if there is no autoconf-generated config.h file */

