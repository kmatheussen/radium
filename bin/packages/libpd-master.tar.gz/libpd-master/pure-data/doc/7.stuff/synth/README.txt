This patch (1.poly.synth) is a polyphonic subtractive synthesizer with
a dozen or so voice parameters you can control live or via presets.  Four
presets are defined.  To test, recall a preset (you should see numbers pop up
in all the parameter controls) start the metronome and turn up the output
volume to around 100.


