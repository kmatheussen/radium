# Description

Modeled after T. Rossing and R. Perrin, Vibrations of Bells, Applied Acoustics 2, 1987.

Model height is 1.8 meters.

To turn `standardBell.obj` into a Faust physical model (`standardBellModel.lib`), just run `./build`.
