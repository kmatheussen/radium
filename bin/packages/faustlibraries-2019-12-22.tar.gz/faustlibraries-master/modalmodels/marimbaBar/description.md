# Description

Model is 440mm*50mm (C2 bar).

To turn `marimbaBar.obj` into a Faust physical model (marimbaBarModel.lib), just run `./build`.
