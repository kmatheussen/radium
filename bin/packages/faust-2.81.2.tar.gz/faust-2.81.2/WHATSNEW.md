## Faust - Programming Language for Audio Applications and Plugins

The Faust project is now described in the [README](https://github.com/grame-cncm/faust) file. The project releases can be accessed [here](https://github.com/grame-cncm/faust/releases).
