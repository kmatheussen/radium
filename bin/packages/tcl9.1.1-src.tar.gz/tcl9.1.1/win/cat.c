/*
 * cat.c --
 *
 *	Program used when testing tclWinPipe.c
 *
 * Copyright © 1996 by Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and redistribution of
 * this file, and for a DISCLAIMER OF ALL WARRANTIES.
 */

#include <stdio.h>
#include <io.h>
#include <string.h>
#include <tchar.h>

int
_tmain(void)
{
    char buf[1024];
    int n;
    const char *err;

    while (1) {
	n = _read(0, buf, sizeof(buf));
	if (n <= 0) {
	    break;
	}
	_write(1, buf, n);
    }
    err = (sizeof(int) == 2) ? "stderr16" : "stderr32";
    _write(2, err, (unsigned int)strlen(err));

    return 0;
}
